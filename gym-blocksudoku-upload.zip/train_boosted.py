import gym
import gym_blocksudoku  # Registers "blocksudoku-v0" with classic Gym.
import numpy as np
from sb3_contrib import MaskablePPO
from sb3_contrib.common.wrappers import ActionMasker
from shimmy import GymV21CompatibilityV0


ENV_ID = "blocksudoku-v0"
TOTAL_TIMESTEPS = 500_000
TENSORBOARD_LOG_DIR = "./blocksudoku_tensorboard/"
MODEL_OUTPUT = "ppo_blockudoku_boosted"

BRICK_REWARD_MULTIPLIER = 10
LINE_CLEAR_REWARD = 500
COMBO_BASE_REWARD = 50


def mask_fn(env):
    valid_actions = env.unwrapped.get_valid_action_space()
    return valid_actions.astype(bool)


def make_gymnasium_env():
    classic_env = gym.make(ENV_ID, disable_env_checker=True)
    classic_env = BoostedBlockudokuRewardWrapper(classic_env)
    gymnasium_env = GymV21CompatibilityV0(env=classic_env)
    return ActionMasker(gymnasium_env, mask_fn)


class BoostedBlockudokuRewardWrapper(gym.Wrapper):
    """Replace low package rewards with high-value brick, clear, and combo marks."""

    def __init__(self, env):
        super().__init__(env)
        self.combo_streak = 0

    def reset(self, **kwargs):
        self.combo_streak = 0
        return self.env.reset(**kwargs)

    def step(self, action):
        action_index = int(np.asarray(action).item())
        base_env = self.unwrapped
        board_before = np.asarray(base_env.main_board[:9, :9], dtype=int).copy()

        queue_pos, x_pos, y_pos = self.decode_action(action_index)
        selected_block = self.get_selected_block(base_env, queue_pos)
        placed_board = self.preview_board_after_placement(board_before, selected_block, x_pos, y_pos)

        obs, original_reward, done, info = self.env.step(action_index)
        reward = self.calculate_boosted_reward(
            original_reward=original_reward,
            selected_block=selected_block,
            placed_board=placed_board,
        )

        return obs, reward, done, info

    @staticmethod
    def decode_action(action_index):
        queue_pos = action_index // 81
        remainder = action_index % 81
        x_pos = remainder // 9
        y_pos = remainder % 9
        return queue_pos, x_pos, y_pos

    @staticmethod
    def get_selected_block(base_env, queue_pos):
        if queue_pos >= len(base_env.block_queue):
            return None
        return np.asarray(base_env.block_queue[queue_pos], dtype=int)

    @staticmethod
    def preview_board_after_placement(board, selected_block, x_pos, y_pos):
        if selected_block is None:
            return None

        placed_board = board.copy()
        block_rows, block_cols = selected_block.shape
        end_row = x_pos + block_rows
        end_col = y_pos + block_cols

        if x_pos < 0 or y_pos < 0 or end_row > 9 or end_col > 9:
            return None

        placed_board[x_pos:end_row, y_pos:end_col] += selected_block
        if placed_board.max() > 1:
            return None

        return placed_board

    def calculate_boosted_reward(self, original_reward, selected_block, placed_board):
        if selected_block is None or placed_board is None:
            self.combo_streak = 0
            return float(original_reward)

        brick_count = int(np.sum(selected_block > 0))
        base_reward = BRICK_REWARD_MULTIPLIER * brick_count

        lines_cleared = self.count_cleared_lines(placed_board)
        line_reward = LINE_CLEAR_REWARD * lines_cleared

        if lines_cleared > 0:
            self.combo_streak += 1
            combo_reward = COMBO_BASE_REWARD * (2 ** (self.combo_streak - 1))
        else:
            self.combo_streak = 0
            combo_reward = 0

        return float(base_reward + line_reward + combo_reward)

    @staticmethod
    def count_cleared_lines(board):
        lines_cleared = 0
        lines_cleared += int(np.sum(board.sum(axis=1) == 9))
        lines_cleared += int(np.sum(board.sum(axis=0) == 9))

        for row_block in range(3):
            for col_block in range(3):
                row_start = row_block * 3
                col_start = col_block * 3
                square = board[row_start : row_start + 3, col_start : col_start + 3]
                if square.sum() == 9:
                    lines_cleared += 1

        return lines_cleared


def main():
    print("Starting boosted MaskablePPO training from scratch...")
    print("Creating Blockudoku environment with action masking and boosted rewards...")

    env = make_gymnasium_env()
    valid_actions = int(env.action_masks().sum())
    print(f"Action mask active. Legal actions on reset: {valid_actions}")

    model = MaskablePPO(
        "MlpPolicy",
        env,
        ent_coef=0.05,
        learning_rate=0.00025,
        clip_range=0.2,
        verbose=1,
        tensorboard_log=TENSORBOARD_LOG_DIR,
    )

    print(f"Training for {TOTAL_TIMESTEPS:,} timesteps with masked actions...")
    model.learn(total_timesteps=TOTAL_TIMESTEPS, progress_bar=True)

    model.save(MODEL_OUTPUT)
    print(f"Training complete. Model saved as {MODEL_OUTPUT}.zip")
    print(f"TensorBoard logs are in: {TENSORBOARD_LOG_DIR}")
    print(f"Open TensorBoard with: tensorboard --logdir {TENSORBOARD_LOG_DIR}")
    env.close()


if __name__ == "__main__":
    main()
